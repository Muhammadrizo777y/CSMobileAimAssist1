CS Mobile Aim Assist Settings — Android Studio project

Что это:
- Прототип Android-приложения с экраном настроек: FOV, плавность, дистанция, выбор Head/Body.
- Это НЕ рабочий игровой Aim Assist и не подключается к CS Mobile.
- Приложение не читает память игры, не отслеживает противников и не меняет управление в матче.

Как собрать APK:
1. Установи Android Studio.
2. Распакуй ZIP.
3. В Android Studio выбери Open и укажи папку CSMobileAimAssist.
4. Дождись синхронизации Gradle.
5. Выбери Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK появится в app/build/outputs/apk/debug/.

Требования:
- Android Studio с JDK 17.
- Android SDK Platform 35.
- Интернет нужен для первой загрузки Gradle-плагинов.
