package com.example.csmobileaimassist

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val blue = Color.rgb(25, 118, 210)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(244, 246, 250))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("CS MOBILE", 13f, blue, true))
        page.addView(label("Aim Assist — settings", 25f, Color.BLACK, true))
        page.addView(label(
            "Demo settings panel. It does not read game data or move the in-game crosshair.",
            14f, Color.DKGRAY, false
        ))

        val enabled = Switch(this).apply {
            text = "Enable demo mode"
            textSize = 17f
            isChecked = false
            setPadding(0, 24, 0, 24)
        }
        page.addView(enabled)

        page.addView(section("Aim settings"))
        page.addView(label("FOV radius: 60", 15f, Color.DKGRAY, false))
        addSlider(page, "FOV radius", 10, 180, 60)
        page.addView(label("Smoothness: 5", 15f, Color.DKGRAY, false))
        addSlider(page, "Smoothness", 1, 10, 5)
        page.addView(label("Maximum distance (demo): 100 m", 15f, Color.DKGRAY, false))
        addSlider(page, "Maximum distance", 10, 300, 100)

        page.addView(section("Target point"))
        val choices = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            addView(RadioButton(this@MainActivity).apply { text = "Head"; id = 1 })
            addView(RadioButton(this@MainActivity).apply { text = "Body"; id = 2 })
            check(1)
        }
        page.addView(choices)

        page.addView(section("Status"))
        val status = TextView(this).apply {
            text = "Demo mode is OFF"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 8, 0, 16)
        }
        page.addView(status)
        enabled.setOnCheckedChangeListener { _, checked ->
            status.text = if (checked) "Demo mode is ON — settings are local only"
                          else "Demo mode is OFF"
        }

        val save = Button(this).apply {
            text = "Save settings"
            setOnClickListener {
                Toast.makeText(this@MainActivity,
                    "Settings saved for this demo session", Toast.LENGTH_SHORT).show()
            }
        }
        page.addView(save)
        page.addView(label(
            "Important: This app is only a visual settings prototype. Real Aim Assist requires official game support; this app does not modify CS Mobile, inspect memory, or provide an advantage in matches.",
            12f, Color.GRAY, false
        ))
    }

    private fun section(text: String): TextView = label(text, 18f, Color.BLACK, true).apply {
        setPadding(0, 24, 0, 8)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 6, 0, 6)
        }

    private fun addSlider(parent: LinearLayout, name: String, min: Int, max: Int, initial: Int) {
        val value = TextView(this).apply {
            text = "$name: $initial"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        }
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = initial - min
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                value.text = "$name: ${progress + min}"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        parent.addView(value)
        parent.addView(seek, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
    }
}
